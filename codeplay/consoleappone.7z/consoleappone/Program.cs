﻿using System;
using classapptwo;

namespace consoleappone
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            ComputeTax ct=new ComputeTax();
            var mytax =ct.StateTax(20000,18);
            Console.WriteLine(mytax);
        }
    }
}
