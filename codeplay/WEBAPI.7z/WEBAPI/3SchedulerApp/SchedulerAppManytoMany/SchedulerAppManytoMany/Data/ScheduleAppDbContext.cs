﻿using Microsoft.EntityFrameworkCore;
using SchedulerAppManytoMany.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulerAppManytoMany.Data
{
    public class ScheduleAppDbContext:DbContext
    {
        public ScheduleAppDbContext(DbContextOptions options) : base(options) {
            Database.EnsureCreated();
        }

    public DbSet<Schedule> Schedules { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserSchedule> UserSchedules { get; set; }
    }
}
