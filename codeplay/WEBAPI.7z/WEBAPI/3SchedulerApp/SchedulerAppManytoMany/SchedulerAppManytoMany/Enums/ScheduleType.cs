﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulerAppManytoMany.Enums
{
    public enum ScheduleType
    {
        Meeting =1,
        Leisure=2,
        Travel=3,
        ClientPhoneConf=4,
        HouseKeeping=5,
        Miscellaneous=6
    }
}
