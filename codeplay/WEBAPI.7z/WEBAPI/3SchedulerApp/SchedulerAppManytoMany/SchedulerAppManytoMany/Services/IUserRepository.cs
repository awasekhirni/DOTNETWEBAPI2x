﻿using SchedulerAppManytoMany.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulerAppManytoMany.Services
{
    public interface IUserRepository
    {
        
        IEnumerable<User> GetAllUsers();
        User GetUserById(int id);
        User RemoveUserById(int id);
        User Add(User User);
        User UpdateUser(User User);
    }
}
