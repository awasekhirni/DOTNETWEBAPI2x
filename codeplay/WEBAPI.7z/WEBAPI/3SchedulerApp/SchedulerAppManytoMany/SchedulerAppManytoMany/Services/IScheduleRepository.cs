﻿using SchedulerAppManytoMany.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulerAppManytoMany.Services
{
    interface IScheduleRepository
    {

        IEnumerable<Schedule> GetAllSchedules();
        Schedule GetScheduleById(int id);
        Schedule RemoveScheduleById(int id);
        Schedule Add(Schedule Schedule);
        Schedule UpdateSchedule(Schedule Schedule);
    }
}
