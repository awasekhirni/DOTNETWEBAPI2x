﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchedulerAppManytoMany.Data;
using SchedulerAppManytoMany.Models;

namespace SchedulerAppManytoMany.Services
{
    public class ScheduleRepositoryService : IScheduleRepository
    {
        public ScheduleAppDbContext _context;

        public ScheduleRepositoryService(ScheduleAppDbContext context)
        {
            _context = context;

        }
        public Schedule Add(Schedule Schedule)
        {
            _context.Schedules.Add(Schedule);
            _context.SaveChanges();
            return Schedule;
        }

        public IEnumerable<Schedule> GetAllSchedules()
        {
            return _context.Schedules.OrderBy(s => s.ScheduleId);
        }

        public Schedule GetScheduleById(int id)
        {
            return _context.Schedules.FirstOrDefault(s => s.ScheduleId == id);
        }

        public Schedule RemoveScheduleById(int id)
        {
            throw new NotImplementedException();
        }

        public Schedule UpdateSchedule(Schedule Schedule)
        {
            throw new NotImplementedException();
        }
    }
}
