﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchedulerAppManytoMany.Data;
using SchedulerAppManytoMany.Models;

namespace SchedulerAppManytoMany.Services
{
    public class UserRepositoryService : IUserRepository
    {
        public ScheduleAppDbContext _context;

        public UserRepositoryService(ScheduleAppDbContext context)
        {
            _context = context;

        }
        public User Add(User User)
        {
            _context.Users.Add(User);
            _context.SaveChanges();
            return User;
        }

        public IEnumerable<User> GetAllUsers()
        {
            return _context.Users.OrderBy(u => u.UserId);
        }

        public User GetUserById(int id)
        {
            return _context.Users.FirstOrDefault(u => u.UserId == id);
        }

        public User RemoveUserById(int id)
        {
            throw new NotImplementedException();
        }

        public User UpdateUser(User User)
        {
            throw new NotImplementedException();
        }
    }
}
