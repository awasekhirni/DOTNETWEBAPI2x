﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulerAppManytoMany.Models
{
    public class Schedule
    {

        public int ScheduleId { get; set; }
        public string ScheduleTitle { get; set; }
        public string ScheduleDesc { get; set; }
        public string ScheduleType { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime DateUpdated { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        public virtual ICollection<UserSchedule> UserSchedules { get; set; }
    }
}
