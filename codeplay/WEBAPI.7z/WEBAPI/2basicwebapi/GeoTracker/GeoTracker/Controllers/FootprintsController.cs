﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace GeoTracker.Controllers
{
    [Route("api/[controller]")]
    public class FootprintsController : Controller
    {
        // GET api/footprints
        [HttpGet]
        public JsonResult Index()
        {
            return new JsonResult(new List<object>() {

                new {id=123124, XCoord=12.1123, YCoord=53.1212,CapturedBy="Syed Awase"},
                new {id=123124, XCoord=12.6723, YCoord=55.1132,CapturedBy="Syed Awase"},
                new {id=123124, XCoord=12.5623, YCoord=58.4312,CapturedBy="Syed Awase"},
                new {id=123124, XCoord=12.9923, YCoord=57.8712,CapturedBy="Syed Awase"},
                new {id=123124, XCoord=11.1123, YCoord=52.9412,CapturedBy="Syed Awase"}


            });
        }
    }
}