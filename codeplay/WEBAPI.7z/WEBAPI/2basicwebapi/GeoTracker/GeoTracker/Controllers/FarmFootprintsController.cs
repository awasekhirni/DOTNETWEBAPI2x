﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GeoTracker.Models;
using Microsoft.AspNetCore.Mvc;

namespace GeoTracker.Controllers
{
    [Route("api/[controller]")]
    public class FarmFootprintsController : Controller
    {
        // GET api/farmfootprints
        [HttpGet]
        public JsonResult Index()
        {
            return new JsonResult(FarmFootprintDataStore.Current.FarmFootprints);
        }

        [HttpGet("{id}")]

        public JsonResult GetFarmFootprintById(int id)
        {
            return new JsonResult(
                FarmFootprintDataStore.Current.FarmFootprints.FirstOrDefault(f => f.FarmId == id)
                );
        }

    }
}