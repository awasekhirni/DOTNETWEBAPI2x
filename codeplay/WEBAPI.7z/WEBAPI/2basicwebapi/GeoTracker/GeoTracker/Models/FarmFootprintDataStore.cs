﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoTracker.Models
{
    public class FarmFootprintDataStore
    {
        //static property to fetch data 
        //c#6 autoproperty initializer syntax.
        public static FarmFootprintDataStore Current { get; } = new FarmFootprintDataStore();
        public List<FarmFootprint> FarmFootprints { get; set; }

        public FarmFootprintDataStore()
        {
            FarmFootprints = new List<FarmFootprint>()
                {
                    new FarmFootprint()
                    {
                        FarmId=122,
                        FarmDescription="Farm House with 3 crops and floral plantation and sheeps",
                        FarmTitle="MoinFarms",
                        FarmGeoFence="12.12 53.123, 12.24 53.46, 12.36 53.89, 12.45 54.01, 12.36 54.49,12.12 53.123 "
                    },
                      new FarmFootprint()
                    {
                        FarmId=123,
                        FarmDescription="Farm House with 6 crops and floral plantation and sheeps",
                        FarmTitle="SadathFarms",
                        FarmGeoFence="13.12 63.123, 13.24 63.46, 13.36 63.89, 13.45 64.01, 13.36 64.49,13.12 63.123 "
                    }

                };
        }
    }
}
