﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoTracker.Models
{
    public class FarmFootprint
    {
        public int FarmId { get; set; }
        public string FarmTitle { get; set; }
        public string FarmDescription { get; set; }
        public string  FarmGeoFence { get; set; }
    }
}
